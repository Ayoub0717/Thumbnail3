import React from 'react';

function Home() {
  return (
    <div>
      <h1>Welcome to Your Next.js App</h1>
      <p>This is your homepage.</p>
    </div>
  );
}

export default Home;
